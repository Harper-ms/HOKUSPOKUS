package com.focuslock2

import android.content.Context
import android.content.SharedPreferences

object Storage {
    private const val prefsName = "focuslock_prefs"
    private const val keyLockedApps = "locked_apps"
    private const val keyTasks = "tasks"
    private const val keyLogs = "completion_logs"
    private const val keyBlockedUntil = "blocked_until"
    private const val keyRequirePin = "require_pin"

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(prefsName, Context.MODE_PRIVATE)

    fun getLockedApps(context: Context): Set<String> =
        prefs(context).getStringSet(keyLockedApps, emptySet()) ?: emptySet()

    fun setLockedApps(context: Context, packages: Set<String>) {
        prefs(context).edit().putStringSet(keyLockedApps, packages).apply()
    }

    fun getTasks(context: Context): List<String> =
        prefs(context).getString(keyTasks, "")
            ?.takeIf { it.isNotEmpty() }
            ?.split("\n")
            ?: emptyList()

    fun setTasks(context: Context, tasks: List<String>) {
        prefs(context).edit().putString(keyTasks, tasks.joinToString("\n")).apply()
    }

    fun addLog(context: Context, message: String) {
        val existing = getLogs(context)
        val updated = existing + message
        prefs(context).edit().putString(keyLogs, updated.joinToString("\n")).apply()
    }

    fun getLogs(context: Context): List<String> =
        prefs(context).getString(keyLogs, "")
            ?.takeIf { it.isNotEmpty() }
            ?.split("\n")
            ?: emptyList()

    fun getBlockedUntil(context: Context): Map<String, Long> {
        val raw = prefs(context).getString(keyBlockedUntil, "") ?: ""
        if (raw.isEmpty()) return emptyMap()
        return raw.split("\n").mapNotNull { line ->
            val idx = line.indexOf('=')
            if (idx <= 0) null else {
                val pkg = line.substring(0, idx)
                val ts = line.substring(idx + 1).toLongOrNull()
                if (ts == null) null else pkg to ts
            }
        }.toMap()
    }

    fun setBlockedUntil(context: Context, data: Map<String, Long>) {
        val raw = data.entries.joinToString("\n") { "${it.key}=${it.value}" }
        prefs(context).edit().putString(keyBlockedUntil, raw).apply()
    }

    fun setBlockUntil(context: Context, pkg: String, untilMillis: Long) {
        val current = getBlockedUntil(context).toMutableMap()
        current[pkg] = untilMillis
        setBlockedUntil(context, current)
    }

    fun clearBlock(context: Context, pkg: String) {
        val current = getBlockedUntil(context).toMutableMap()
        current.remove(pkg)
        setBlockedUntil(context, current)
    }

    fun isBlocked(context: Context, pkg: String): Boolean {
        val until = getBlockedUntil(context)[pkg] ?: return false
        return System.currentTimeMillis() < until
    }

    fun getRequirePin(context: Context): Boolean =
        prefs(context).getBoolean(keyRequirePin, true)

    fun setRequirePin(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(keyRequirePin, value).apply()
    }
}