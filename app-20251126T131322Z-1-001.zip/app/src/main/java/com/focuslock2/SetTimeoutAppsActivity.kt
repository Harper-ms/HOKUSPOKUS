package com.focuslock2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class AppTimeout(val app: String, val timeout: String)

class SetTimeoutAppsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SetTimeoutAppsScreen() }
    }
}

@Composable
fun SetTimeoutAppsScreen() {
    var apps by remember { mutableStateOf(
        listOf(
            AppTimeout("YouTube", "00:30"),
            AppTimeout("Games", "01:00"),
            AppTimeout("Browser", "00:15")
        )
    ) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("SET APPLICATIONS FOR TIMEOUT", style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(modifier = Modifier.weight(1f)) {
            items(apps) { app -> Text("${app.app} — ${app.timeout}", modifier = Modifier.padding(vertical = 4.dp)) }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = {
            apps = apps + AppTimeout("New App", "00:10")
        }, modifier = Modifier.fillMaxWidth()) {
            Text("+ ADD MORE")
        }
    }
}
