package com.focuslock2

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.content.Intent

class FocusLockAccessibilityService : AccessibilityService() {
    private var lastPackage: String? = null
    private var lastLaunchAt: Long = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        try {
            val type = event?.eventType ?: return
            if (type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && type != AccessibilityEvent.TYPE_WINDOWS_CHANGED) return
            val pkg = event.packageName?.toString() ?: return
            if (pkg == packageName) return
            val now = System.currentTimeMillis()
            if (pkg == lastPackage && now - lastLaunchAt < 1500) return
            val locked = Storage.getLockedApps(applicationContext)
            val isTimeBlocked = Storage.isBlocked(applicationContext, pkg)
            if (locked.contains(pkg) || isTimeBlocked) {
                lastPackage = pkg
                lastLaunchAt = now
                performGlobalAction(GLOBAL_ACTION_HOME)
                try {
                    val overlay = Intent(applicationContext, AppBlockerOverlayService::class.java)
                    overlay.putExtra("blocked_package", pkg)
                    startService(overlay)
                } catch (_: Exception) {}
                try {
                    val i = Intent(applicationContext, BlockerActivity::class.java)
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    i.putExtra("blocked_package", pkg)
                    startActivity(i)
                } catch (_: Exception) {}
            } else {
                try { stopService(Intent(applicationContext, AppBlockerOverlayService::class.java)) } catch (_: Exception) {}
            }
        } catch (_: Exception) {
            // swallow to avoid service crash
        }
    }

    override fun onInterrupt() {}
}
