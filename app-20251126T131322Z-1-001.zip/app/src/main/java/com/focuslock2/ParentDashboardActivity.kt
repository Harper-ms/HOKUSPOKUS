package com.focuslock2

import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext

class ParentDashboardActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ParentDashboardScreen()
        }
    }
}

@Composable
fun ParentDashboardScreen() {
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("Set Apps", "Set Tasks")
    val ctx = LocalContext.current
    var requirePin by remember { mutableStateOf(Storage.getRequirePin(ctx)) }
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Button(onClick = {
                ctx.startActivity(android.content.Intent(ctx, CompletionLogsActivity::class.java))
            }) { Text("View Logs") }
            Button(onClick = {
                ctx.startActivity(android.content.Intent(ctx, OptionsActivity::class.java))
            }) { Text("Options") }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Button(onClick = {
                ctx.startActivity(android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }) { Text("Enable App Lock") }
            Button(onClick = {
                ctx.startActivity(android.content.Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
            }) { Text("Enable Overlay") }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Require PIN to complete tasks", modifier = Modifier.weight(1f))
            Switch(checked = requirePin, onCheckedChange = {
                requirePin = it
                Storage.setRequirePin(ctx, it)
            })
        }
        Spacer(modifier = Modifier.height(8.dp))
        TabRow(selectedTabIndex = selectedTab) {
            tabs.forEachIndexed { index, title ->
                Tab(selected = selectedTab == index, onClick = { selectedTab = index }) {
                    Text(text = title, modifier = Modifier.padding(16.dp))
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        when(selectedTab) {
            0 -> AppTimeoutManager()
            1 -> TaskManagerUI()
        }
    }
}

@Composable
fun AppTimeoutManager() {
    val context = LocalContext.current
    val pm = context.packageManager
    val apps = remember {
        pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .sortedBy { it.loadLabel(pm).toString() }
    }

    var selectedApps by remember { mutableStateOf(Storage.getLockedApps(context)) }
    var blockedUntil by remember { mutableStateOf(Storage.getBlockedUntil(context)) }
    var query by remember { mutableStateOf("") }
    var manualPkg by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Search apps") },
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(8.dp))
            OutlinedTextField(
                value = manualPkg,
                onValueChange = { manualPkg = it },
                label = { Text("Package name") },
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Button(onClick = {
                if (manualPkg.isNotBlank()) {
                    selectedApps = selectedApps + manualPkg
                    Storage.setLockedApps(context, selectedApps)
                    manualPkg = ""
                }
            }) { Text("Lock Package") }
        }
        Spacer(modifier = Modifier.height(8.dp))
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(apps) { app ->
                val appName = app.loadLabel(pm).toString()
                val checked = selectedApps.contains(app.packageName)
                val matches = query.isBlank() || appName.contains(query, ignoreCase = true) || app.packageName.contains(query, ignoreCase = true)
                if (!matches) return@items
                Column(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = checked, onCheckedChange = { isChecked ->
                            selectedApps = if(isChecked) selectedApps + app.packageName else selectedApps - app.packageName
                            Storage.setLockedApps(context, selectedApps)
                        })
                        Text(text = appName, fontSize = 16.sp, modifier = Modifier.padding(start = 8.dp))
                    }
                if(checked) {
                    Row(modifier = Modifier.padding(start = 32.dp), verticalAlignment = Alignment.CenterVertically) {
                        var hours by remember { mutableStateOf(0) }
                        var minutes by remember { mutableStateOf(0) }
                        var seconds by remember { mutableStateOf(0) }
                        var showConfirm by remember { mutableStateOf(false) }

                            ScrollNumberPicker(value = hours, range = 0..23, label = "H") { hours = it }
                            ScrollNumberPicker(value = minutes, range = 0..59, label = "M") { minutes = it }
                            ScrollNumberPicker(value = seconds, range = 0..59, label = "S") { seconds = it }

                        Button(onClick = { showConfirm = true }, modifier = Modifier.padding(start = 8.dp)) {
                            Text("Set Timeout")
                        }
                        Button(onClick = {
                            Storage.clearBlock(context, app.packageName)
                            blockedUntil = Storage.getBlockedUntil(context)
                        }, modifier = Modifier.padding(start = 8.dp)) {
                            Text("Clear")
                        }
                        if (showConfirm) {
                            androidx.compose.material3.AlertDialog(
                                onDismissRequest = { showConfirm = false },
                                confirmButton = {
                                    Button(onClick = {
                                        showConfirm = false
                                        val totalMs = ((hours * 3600) + (minutes * 60) + seconds) * 1000L
                                        if (totalMs > 0L) {
                                            val until = System.currentTimeMillis() + totalMs
                                            Storage.setBlockUntil(context, app.packageName, until)
                                            blockedUntil = Storage.getBlockedUntil(context)
                                        }
                                    }) { Text("Confirm") }
                                },
                                dismissButton = {
                                    Button(onClick = { showConfirm = false }) { Text("Cancel") }
                                },
                                title = { Text("Confirm Timeout") },
                                text = { Text("Apply timeout ${hours}h ${minutes}m ${seconds}s to ${appName}?") }
                            )
                        }
                    }
                    val until = blockedUntil[app.packageName]
                    if (until != null) {
                        val remaining = until - System.currentTimeMillis()
                        if (remaining > 0) {
                                val h = (remaining / 3600000)
                                val m = ((remaining % 3600000) / 60000)
                                val s = ((remaining % 60000) / 1000)
                                Text("Remaining: ${h}h ${m}m ${s}s", modifier = Modifier.padding(start = 32.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ScrollNumberPicker(value: Int, range: IntRange, label: String, onValueChange: (Int) -> Unit) {
    Column(modifier = Modifier.padding(end=8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label)
        androidx.compose.foundation.lazy.LazyRow(
            modifier = Modifier.width(160.dp)
        ) {
            items(range.count()) { idx ->
                val num = range.first + idx
                val selected = num == value
                Box(modifier = Modifier
                    .padding(4.dp)
                    .width(44.dp)
                    .height(44.dp), contentAlignment = Alignment.Center) {
                    Button(onClick = { onValueChange(num) }) {
                        Text(if (selected) "$num" else "$num")
                    }
                }
            }
        }
        Text("$value")
    }
}

@Composable
fun TaskManagerUI() {
    val context = LocalContext.current
    var tasks by remember { mutableStateOf(Storage.getTasks(context).toMutableList()) }
    var newTask by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(tasks) { task ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(4.dp)) {
                    Text(task, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    Button(onClick = {
                        tasks.remove(task)
                        Storage.setTasks(context, tasks)
                    }) { Text("Remove") }
                }
            }
        }
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = newTask,
                onValueChange = { newTask = it },
                label = { Text("New Task") },
                modifier = Modifier.weight(1f)
            )
            Button(onClick = {
                if(newTask.isNotBlank()) {
                    tasks.add(newTask)
                    Storage.setTasks(context, tasks)
                    newTask = ""
                }
            }, modifier = Modifier.padding(start=8.dp)) {
                Text("Add")
            }
        }
    }
}
